/*
Viagens entre cidades

2001/10/24
*/


% Base de dados: Rede de Expressos
% expresso(origem, destino)

expresso(lisboa, coimbra).
expresso(lisboa, leiria).
expresso(lisboa, santarem).
expresso(santarem, leiria).	% Ciclo
expresso(leiria, lisboa).	% Ciclo
expresso(leiria, coimbra).
expresso(santarem, coimbra).
expresso(coimbra, aveiro).
expresso(aveiro, braga).
expresso(aveiro, porto).

expresso(braga, porto).
expresso(braga, guimaraes).
expresso(braga, viana).

expresso(porto, guimaraes).
expresso(porto, viana).

