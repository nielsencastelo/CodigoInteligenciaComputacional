/*
Viagens entre cidades

2001/10/24
*/

% Base de dados: cidades
cidade(lisboa).
cidade(leiria).
cidade(santarem).
cidade(coimbra).
cidade(aveiro).
cidade(braga).
cidade(porto).
cidade(guimaraes).
cidade(viana).


% Base de dados: companhias de expressos
% comp(sigla, nome)

comp(rn, 'rodoviaria nacional').
comp(re, 'rede expressos').
comp(ev, 'Eva').
comp(mt, 'mundial turismo').
comp(ca, caima).


% Base de dados: expressos
% (id, origem, destino, companhia)

expresso(rn-1, lisboa, coimbra, rn).
expresso(re-1, lisboa, coimbra, re).
expresso(rn-2, lisboa, leiria, rn).
expresso(ev-1, lisboa, leiria, ev).
expresso(rn-3, lisboa, santarem, rn).
expresso(mt-1, lisboa, santarem, mt).

expresso(ev-2, leiria, coimbra, ev).
expresso(re-2, leiria, coimbra, re).

expresso(mt-2, santarem, coimbra, mt).
expresso(re-3, santarem, coimbra, re).

expresso(re-4, coimbra, aveiro, re).

expresso(re-5, aveiro, braga, re).
expresso(re-6, aveiro, porto, re).

expresso(ca-2, braga, guimaraes, ca).
expresso(ca-3, braga, viana, ca).

expresso(ca-4, porto, guimaraes, ca).
expresso(ca-5, porto, viana, ca).

