/*

Altern�ncia de jogadas


Lu�s
2005-12-02

*/


% Sistema de produ��o para controlar a altern�ncia de jogadas
% no jogo do Galo

:- ensure_loaded('C:\usr\luis\aulas\_ia\KbSystems\ProductionSystem.pl').


/*
Representa��o do estado

Os dois jogadores:
jogador(1, <Nome1>).
jogador(2, <Nome2>).

Marca de um jogador: o +
jogador_marca(<Nome>, <Marca>), por exemplo jogador_marca(maria, o).


Pr�ximo jogador a jogar
proximo(<Nome>).


Tabuleiro
tabuleiro(T) em que T = t/9


Resultado do jogo
final(Tabuleiro, Resultado) em que o Resultado pode ser galo (empate)
ou o nome de um dos jogadores. Em caso de o jogo n�o ter ainda acabado, final/2 falha

final/2 � implementado em Prolog

*/



% Regras
%
if (\+jogador(1, _)) then (ler_nome_jogador(1, Nome), assert(jogador(1, Nome))).

if (\+jogador(2, _)) then (ler_nome_jogador(2, Nome), assert(jogador(2, Nome))).

if (jogador(N, J), \+jogador_marca(_, _)) then (ler_marca(J, Marca), assert(jogador_marca(J, Marca))).
if (jogador(N1, J1), \+jogador_marca(J1, _), seguinte(N1, N2), jogador(N2, J2), jogador_marca(J2, M2), seguinte(M2, M1))
then assert(jogador_marca(J1, M1)).


if (\+proximo(_), jogador_marca(J, o)) then assert(proximo(J)).

if (\+tabuleiro(T)) then (criar_tabuleiro(T), assert(tabuleiro(T))).


if (tabuleiro(T), proximo(J), \+final(T, _))
then (mostrar_tabuleiro(T), ler_jogada(J, Jogada), actualizar_tabuleiro(J, Jogada), troca_jogador).


if (tabuleiro(T), final(T, galo)) then (anunciar_empate, limpar).
if (tabuleiro(T), final(T, Jogador), Jogador \= galo) then (anunciar_vitoria(Jogador), limpar).




% Ac��es
%
ler_nome_jogador(N1, Nome1):-
	seguinte(N1, N2),
	(jogador(N2, Nome2); Nome2 = nil), !,
	ler_nome_jogador_aux(Nome2, Nome1).

ler_nome_jogador_aux(nil, Nome1):-
	!,
	prompt(Old, ''),
	write('Indica o teu nome: '),
	read(Nome1),
	prompt(_, Old).
ler_nome_jogador_aux(Nome2, Nome1):-
	prompt(Old, ''),
	writelst(['Indica o teu nome. Tem de ser diferente de ', Nome2, ': ']),
	read(Nome1),
	prompt(_, Old).

ler_marca(Jogador, Marca):-
	prompt(Old, ''),
	writelst([Jogador, ', que marca escolhes (o / +): ']),
	read(Marca),
	prompt(_, Old).


ler_jogada(J, Jogada):-
	writelst([J, ', indica a posi��o da tua jogada (1 a 9): ']), read(Jogada).


criar_tabuleiro(T):-
	functor(T, t, 9).

mostrar_tabuleiro(t(X1, X2, X3, X4, X5, X6, X7, X8, X9)):-
	desenhar_tracejado, nl,
	mostrar_linha(1, X1, X2, X3), nl,
	desenhar_tracejado, nl,
	mostrar_linha(2, X4, X5, X6), nl,
	desenhar_tracejado, nl,
	mostrar_linha(3, X7, X8, X9), nl,
	desenhar_tracejado, nl.

desenhar_tracejado:-
	write('+---+---+---+').

mostrar_linha(N, X1, X2, X3):-
	Offset is (N - 1) * 3 + 1,
	Pos1 is Offset + 0,
	write('| '), mostrar_conteudo(Pos1, X1), write(' '),
	Pos2 is Offset + 1,
	write('| '), mostrar_conteudo(Pos2, X2), write(' '),
	Pos3 is Offset + 2,
	write('| '), mostrar_conteudo(Pos3, X3), write(' |').


mostrar_conteudo(Pos, X):-
	var(X),
	!,
	write(Pos).
mostrar_conteudo(_, X):-
	write(X).



% Actualiza o tabuleiro e o facto que o armazena
actualizar_tabuleiro(J, Jogada):-
	jogador_marca(J, M),
	retract(tabuleiro(T)),
	arg(Jogada, T, M),
	assert(tabuleiro(T)),
	!.


% Troca o jogador, actualizando o facto proximo/1
troca_jogador :-
	retract(proximo(J1)),
	jogador(N1, J1),
	seguinte(N1, N2),
	jogador(N2, J2),
	assert(proximo(J2)).

anunciar_empate:-
	write('Empate'), nl.

anunciar_vitoria(Jogador):-
	writelst([Jogador, ' ganha! Parabens.']), nl.


writelst([X|L]):-
	write(X),
	writelst(L).
writelst([]).


limpar:-
	(retract(jogador(1, _)); true),
	(retract(jogador(2, _)); true),
	(retract(jogador_marca(_, +)); true),
	(retract(jogador_marca(_, o)); true),
	(retract(proximo(_)); true),
	(retract(tabuleiro(_)); true).


% Predicados
%

% final(T, Resultado)

final(T, Jogador):-
	jogador_marca(Jogador, Marca),
	linha([Pos1, Pos2, Pos3]),
	marca(T, Pos1, Marca),
	marca(T, Pos2, Marca),
	marca(T, Pos3, Marca),
	!.
final(T, galo):-
	preenchido(T),
	\+ ((jogador(_, J), final(T, J))).

marca(T, Pos1, Marca):-
	arg(Pos1, T, X),
	X == Marca.


preenchido(T):-
	ground(T).


seguinte(1, 2).
seguinte(2, 1).
seguinte(o, '+').
seguinte('+', o).


linha([1, 2, 3]).
linha([4, 5, 6]).
linha([7, 8, 9]).

linha([1, 4, 7]).
linha([2, 5, 8]).
linha([3, 6, 9]).

linha([1, 5, 9]).
linha([3, 5, 7]).
