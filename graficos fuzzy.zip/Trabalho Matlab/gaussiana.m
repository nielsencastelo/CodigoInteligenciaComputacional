x = -3:0.01:3;
f = exp(-x.^2)/(2) %sig = 0.1^2)
plot(x,f)