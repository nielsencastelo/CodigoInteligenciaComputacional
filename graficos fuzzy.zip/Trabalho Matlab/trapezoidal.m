a=1;
b=5;
c=7;
d=8;
x = 0:0.1:10;
plot(x,max(min((x - a)/(b - a)),1,((d - x)/(d - c)),0))