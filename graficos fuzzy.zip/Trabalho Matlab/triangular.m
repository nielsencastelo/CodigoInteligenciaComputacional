a=1
b=3
c=5
x = 0:0.1:10;
plot(x,max(min((x-a)/(b-a),(c-x)/(c-b)),0))
