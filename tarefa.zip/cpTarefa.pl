/*
Candidatos para efectuarem uma tarefa

Topicos:
(1) Encadeamento para tras vs. encadeamento para a frente.
(2) Depth-first vs. breadth-first

97/10/11
<>
*/

% Base de dados: tarefas (ainda nao e' necessario)
%
% Teste sistematico de programas de computador

% Regras de seleccao de candidatos (testp)
% Introducao de dados num sistema de documentacao (intrd)
% Secretariado (secr)

tarefa(testp).
tarefa(intrd).
tarefa(secr).

% Base de dados: empregados

empregado(alves).	% Ainda nao e' necessario
empregado(matos).	% Ainda nao e' necessario

% Alves
horas_contratuais(alves, 40).
horas_atribuidas(alves, 20).
permitido(alves, testp).
capacidade(alves, testp).
gosta(alves, testp).
melhora_curric(alves, testp).


% Matos
horas_contratuais(matos, 40).
horas_atribuidas(matos, 15).
permitido(matos, secr).
capacidade(matos, secr).
gosta(matos, secr).


% Regras para seleccionar candidatos

candidato(A, T) :-
	disponivel(A, T),
	capacidade(A, T),
	interesse(A, T).

disponivel(A, T) :-
	tempo_disp(A),		% Tempo disponivel
	permitido(A, T).	% E' permitido A efectuar T

tempo_disp(A) :-
	horas_contratuais(A, N),
	horas_atribuidas(A, M),
	N > M.

interesse(A, T) :-
	gosta(A, T).
interesse(A, T) :-
	melhora_curric(A, T).

