/*
Voos entre cidades

97/10/07
*/


% Base de dados: Voos
% voo(origem, destino)

voo(lisboa, frankfurt).
voo(lisboa, londres).
voo(lisboa, paris).
voo(paris, londres).	% Ciclo
voo(londres, lisboa).	% Ciclo
voo(londres, frankfurt).
voo(paris, frankfurt).
voo(frankfurt, munique).
voo(munique, osaka).
voo(munique, tokio).

voo(osaka, tokio).
voo(osaka, sapporo).
voo(osaka, yokohama).

voo(tokio, sapporo).
voo(tokio, yokohama).

