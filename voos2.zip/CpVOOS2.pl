/*
Voos entre cidades

97/10/07
VOOS2.PL
*/

% Base de dados: cidades
cidade(lisboa).
cidade(londres).
cidade(paris).
cidade(frankfurt).
cidade(munich).
cidade(osaka).
cidade(tokio).
cidade(sapporo).
cidade(yokohama).


% Base de dados: companhias de aviacao
% comp(sigla, nome)

comp(tp, 'air portugal').
comp(lu, lufthansa).
comp(ba, 'british airways').
comp(af, 'air france').
comp(jal, 'japan airlines').


% Base de dados: Voos
% voo(id, origem, destino, companhia)

voo(tp-1, lisboa, frankfurt, tp).
voo(lu-1, lisboa, frankfurt, lu).
voo(tp-2, lisboa, londres, tp).
voo(ba-1, lisboa, londres, ba).
voo(tp-3, lisboa, paris, tp).
voo(af-1, lisboa, paris, af).

voo(ba-2, londres, frankfurt, ba).
voo(lu-2, londres, frankfurt, lu).

voo(af-2, paris, frankfurt, af).
voo(lu-3, paris, frankfurt, lu).

voo(lu-4, frankfurt, munich, lu).

voo(lu-5, munich, osaka, lu).
voo(lu-6, munich, tokio, lu).

voo(ja-1, osaka, tokio, jal).
voo(ja-2, osaka, sapporo, jal).
voo(ja-3, osaka, yokohama, jal).

voo(ja-4, tokio, sapporo, jal).
voo(ja-5, tokio, yokohama, jal).

